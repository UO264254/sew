<!DOCTYPE html>

<html lang="es">

    <head>
        <!--Datos que describen el documento-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <meta charset="UTF-8"/>

        <!--Metadatos estándares-->
        <meta name="author" content="Alejo Brandy García-Rovés"/>
    
        <title>Ejercicio Temática Libre</title>

        <link rel="stylesheet" type="text/css" href="Ejercicio7.css" />

    </head>

    <body>
        <!--Datos con el contenido que aparece en el navegador-->
        <header>
            <h1>Ejercicio Temática Libre</h1>
        </header>
         <!--Menu de navegación principal-->
    <nav>
        <ul>
            <li>
                <a title="Crear Base de Datos"
                tabindex= "1"
                accesskey="C" 
                href="Ejercicio7.php?crearBD">
                            Crear Base de Datos</a>
            </li>
            <li>
                <a title="Crear una tabla"
                tabindex= "2"
                accesskey="R"
                href="Ejercicio7.php?crearTablas">
                            Crear tablas</a>
            </li>
            <li>
                <a title="Importar datos CCAA"
                tabindex= "3"
                accesskey="I"
                href="Ejercicio7.php?importarDatosCCAA" >
                            Importar datos CCAA</a>
            </li>
            <li>
                <a title="Exportar datos CCAA"
                tabindex= "4"
                accesskey="E"
                href="Ejercicio7.php?exportarDatosCCAA" >
                            Exportar datos CCAA</a>
            </li>
            <li>
                <a title="Importar datos Covid_dia"
                tabindex= "5"
                accesskey="M"
                href="Ejercicio7.php?importarDatosCovidDia" >
                            Importar datos de casos de Covid</a>
            </li>
            <li>
                <a title="Exportar datos Covid_dia"
                tabindex= "6"
                accesskey="X"
                href="Ejercicio7.php?exportarDatosCovidDia" >
                            Exportar datos de casos de Covid</a>
            </li>
            <li>
                <a title="Importar datos Normas"
                tabindex= "7"
                accesskey="P"
                href="Ejercicio7.php?importarDatosNormas" >
                            Importar datos de Normas</a>
            </li>
            <li>
                <a title="Exportar datos Normas"
                tabindex= "8"
                accesskey="O"
                href="Ejercicio7.php?exportarDatosNormas" >
                            Exportar datos de Normas</a>
            </li>
            <li>
                <a title="Últimos datos COVID España"
                tabindex= "9"
                accesskey="N"
                href="Informe.php" >
                            Informe</a>
            </li>
            <li>
                <a title="Insertar datos COVID hoy"
                tabindex= "10"
                accesskey="S"
                href="InsertarDatosCOVID.php">
                            Insertar datos COVID hoy </a>
            </li>
            <li>
                <a title="Insertar datos Normas"
                tabindex= "11"
                accesskey="T"
                href="InsertarDatosNormas.php">
                            Insertar datos Normas </a>
            </li>
            <li>
                <a title="Insertar CCAA"
                tabindex= "12"
                accesskey="I"
                href="InsertarDatosCCAA.php">
                            Insertar datos CCAA </a>
            </li>
           <li>
                <a title="Buscar datos COVID comunidad"
                tabindex= "13"
                accesskey="B"
                href="BuscarDatosCOVID.php" >
                            Buscar datos COVID comunidad</a>
            </li>
            <li>
                <a title="Buscar datos Normas"
                tabindex= "13"
                accesskey="U"
                href="BuscarDatosNormas.php" >
                            Buscar datos Normas</a>
            </li>
            <li>
                <a title="Eliminar datos COVID comunidad"
                tabindex= "14"
                accesskey="L"
                href="EliminarDatosCOVID.php" >
                            Eliminar datos COVID comunidad</a>
            </li>
            <li>
                <a title="Eliminar datos Normas"
                tabindex= "15"
                accesskey="O"
                href="EliminarDatosNormas.php" >
                            Eliminar datos Normas</a>
            </li>
            <li>
                <a title="Modificar datos COVID"
                tabindex= "16"
                accesskey="V"
                href="ModificarDatosCOVID.php" >
                            Modificar datos COVID</a>
            </li>
            <li>
                <a title="Modificar datos Normas"
                tabindex= "17"
                accesskey="S"
                href="ModificarDatosNormas.php" >
                            Modificar datos normas</a>
            </li>
        </ul>
    </nav>

        <?php
        
            require 'BaseDatos.php';
            $bd=new BaseDatos();
            
            if (isset($_GET['crearBD'])) {
                $bd->crearBD();
            } else if (isset($_GET['crearTablas'])) {
                $bd->crearTablas();
            } else if (isset($_GET['importarDatosCCAA'])) {
                $bd->importarDatosCCAA();
            } else if (isset($_GET['exportarDatosCCAA'])) {
                $bd->exportarDatosCCAA();
            } else if (isset($_GET['importarDatosCovidDia'])) {
                $bd->importarDatosCovidDia();
            } else if (isset($_GET['exportarDatosCovidDia'])) {
                $bd->exportarDatosCovidDia();
            } else if (isset($_GET['importarDatosNormas'])) {
                $bd->importarDatosNormas();
            } else if (isset($_GET['exportarDatosNormas'])) {
                $bd->exportarDatosNormas();
            } else if (isset($_POST['back'])) {
                //quedarse en esta página
            } 
                else if (isset($_POST['leerComunidad'])) {
                echo "buscarPorComunidad ".$_POST['nombreComunidad'];
                $resultado=$bd->buscarPorComunidad($_POST['nombreComunidad']);
                echo $resultado['nombre'];
                header('location: Informe.php?id='.$resultado['id'].'&codigo='.$resultado['codigo']
                                                .'&nombre='.$resultado['nombre'].'&num_hab='.$resultado['num_hab']);
            }
        ?>
   
    <footer>
        <a href="https://validator.w3.org/check?uri=referer">
            <img src="multimedia/HTML5.png" alt=" HTML5 Válido!" /></a>

        <a href=" http://jigsaw.w3.org/css-validator/check/referer ">
            <img src="multimedia/CSS3.png"
            alt="CSS Válido!" height="63" width="64"/></a>
    </footer>
    </body>
</html>