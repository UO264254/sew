<!DOCTYPE html>
<html lang="es">
<head>
    <title>CCAA</title>
    <meta charset="utf-8"/>   
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Alejo" /> 
    <!-- enlace a la hoja de estilos -->
    <link href="Ejercicio7.css" rel="stylesheet" />
</head>   
<body>
    <section>
        <h1>Formulario</h1>  
        <p>Insertar datos de CCAA</p>
        <form method="post" action="" name="insertarDatos">
            <p><label for="nombre"> Comunidad/Ciudad Autónoma:</label> <input type="text" name="nombre" id="nombre" required/> </p>
            <p><label for="num_hab">Número de habitantes:</label> <input type="number" name="num_hab" id="num_hab" required/> </p>
            <input type="submit" name="insertar" value="Insertar" />
        </form>
        <?php 
            require 'BaseDatos.php';
            $bd=new BaseDatos();
            if (isset($_POST['insertar'])) {
                $registro['nombre'] = $_POST['nombre'];
                $registro['num_hab'] = $_POST['num_hab'];
                $bd->insertarDatosCCAA($registro);
            }
        ?>
    </section>
</body>
</html>