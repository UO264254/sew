/*IdiomaNavegador.js*/
class IdiomaNavegador{
    constructor(){
        document.write("<h2>Idioma: ")
        document.write(infoNavegador.getIdioma());
        document.write("</h2>")
    }
}
var idiomaNavegador = new IdiomaNavegador();
