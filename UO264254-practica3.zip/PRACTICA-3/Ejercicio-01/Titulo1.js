/* Titulo1.js */
class Titulo1 {
    constructor () {
        document.write("<h1>");
        document.write(asignatura.getNombre());
        document.write("</h1>");
    }
}

var titulo1 = new Titulo1();