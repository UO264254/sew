/* Titulo4.js */
class Titulo4 {
    constructor () {
        document.write("<h4>");
        document.write(asignatura.getUniversidad());
        document.write("</h4>");
    }
}
var titulo4 = new Titulo4();