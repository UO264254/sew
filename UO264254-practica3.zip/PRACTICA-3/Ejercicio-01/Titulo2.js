/* Titulo2.js */
class Titulo2 {
    constructor () {
        document.write("<h2>");
        document.write(asignatura.getTitulacion());
        document.write("</h2>");
    }
}
var titulo2 = new Titulo2();