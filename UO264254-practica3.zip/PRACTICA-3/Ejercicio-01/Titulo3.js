/* Titulo3.js */
class Titulo3 {
    constructor () {
        document.write("<h3>");
        document.write(asignatura.getCentro());
        document.write("</h3>");
    }
}
var titulo3 = new Titulo3();