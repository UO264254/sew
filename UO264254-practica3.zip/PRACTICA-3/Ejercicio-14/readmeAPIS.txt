Utilizo las siguientes APIS:
API Fullscreen
API Canvas
API Drag and Drop
API IndexDF
API File